// Enums
// ignore_for_file: constant_identifier_names

enum AnimationDirection { bottomToTop, rightToLeft, leftToRight, topToBottom }

enum LottieImage { add, add_person, delete, edit, search, money }

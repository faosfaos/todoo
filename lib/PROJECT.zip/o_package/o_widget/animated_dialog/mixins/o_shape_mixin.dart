import 'package:flutter/material.dart';

mixin OShapeMixin {
  ShapeBorder? buildShape(BuildContext context) => null;
}
